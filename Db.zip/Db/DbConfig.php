<?php

class DbConfig
{
    // const HOSTNAME="localhost";
    // const USERNAME="root";
    // const PASSWORD="";
    // const DBNAME="shopping_cart";
    
  const HOSTNAME="localhost";
    const USERNAME="bloom46x_shopping";
    const PASSWORD="gE{d]xE@J9+h";
    const DBNAME="bloom46x_shopping_cart";
}
?>
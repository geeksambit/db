<?php

class Constants {

    const Success = "Success";
    const product_add = "Please Enter Product to Cart";
    const userId_unAvailable = "UserId not available";
    const get_notSupport = "Get Request Not Supported";
    //const requi
}   
